# Site Educacional de Geografia

Projeto Next.js 14 + Tailwind.